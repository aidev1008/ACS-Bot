# Node.js App Service Sample

This is a simple Node.js app using Express, ready to deploy to Azure App Service.

## How to run locally

1. Install dependencies:
   npm install
2. Start the app:
   npm start

The app will be available at http://localhost:3000
